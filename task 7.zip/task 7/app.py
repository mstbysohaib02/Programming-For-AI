from flask import Flask, render_template, request
import requests

app = Flask(__name__)

news_api = "pub_12345abcde67890fghij12345klmnopqrstu"
"
news_api_url = "https://newsdata.io/api/1/news"

@app.route('/', methods=['GET', 'POST'])
def home():
    news = {}
    
    if request.method == 'POST':  # Handle search queries
        search_query = request.form.get('search_query', '')
        params = {'apikey': news_api, 'q': search_query}
    else:  # Default latest news
        params = {'apikey': news_api}

    response = requests.get(news_api_url, params=params)

    if response.status_code == 200:
        news = response.json()
    else:
        news = {'error': 'Failed to fetch news. Please try again later.'}

    return render_template('index.html', news=news)

if __name__ == '__main__':
    app.run(debug=True)
