import cv2
import dlib
import numpy as np
from imutils import face_utils
from flask import Flask, render_template, request

# Initialize Flask app
app = Flask(__name__)

# Load pre-trained face detector and shape predictor
face_detector = cv2.CascadeClassifier('haarcascade_frontalface_default.xml')
shape_predictor = dlib.shape_predictor('shape_predictor_68_face_landmarks.dat')

# Define personality mapping based on facial features
def determine_personality(measurements):
    if measurements['Jaw Width'] > 120 and measurements['Eye Width'] > 40:
        return "ENTJ - The Commander (Bold, strategic leader)"
    elif measurements['Nose Height'] > 35 and measurements['Eye Width'] < 40:
        return "INFJ - The Advocate (Visionary, insightful)"
    elif measurements['Jaw Width'] < 110 and measurements['Eye Width'] > 45:
        return "ENFP - The Campaigner (Energetic, enthusiastic)"
    elif measurements['Jaw Width'] > 130:
        return "ISTJ - The Inspector (Organized, responsible)"
    else:
        return "ISFP - The Artist (Creative, spontaneous)"

def detect_facial_features(image):
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    faces = face_detector.detectMultiScale(gray, 1.3, 5)
    
    for (x, y, w, h) in faces:
        rect = dlib.rectangle(int(x), int(y), int(x + w), int(y + h))
        landmarks = shape_predictor(gray, rect)
        landmarks = face_utils.shape_to_np(landmarks)
        
        # Draw landmarks
        for (x, y) in landmarks:
            cv2.circle(image, (x, y), 2, (0, 255, 0), -1)
        
        # Measure distances (Example: Eye Width, Nose Height, Jawline Width)
        eye_width = np.linalg.norm(landmarks[36] - landmarks[39])
        nose_height = np.linalg.norm(landmarks[27] - landmarks[30])
        jaw_width = np.linalg.norm(landmarks[0] - landmarks[16])
        
        measurements = {
            'Eye Width': round(eye_width, 2),
            'Nose Height': round(nose_height, 2),
            'Jaw Width': round(jaw_width, 2)
        }
        
        personality_type = determine_personality(measurements)
        measurements['Personality Type'] = personality_type
        
        return image, measurements
    
    return image, None

@app.route('/', methods=['GET', 'POST'])
def upload_file():
    if request.method == 'POST':
        file = request.files['image']
        if file:
            image_path = 'uploaded_image.jpg'
            file.save(image_path)
            image = cv2.imread(image_path)
            processed_image, face_data = detect_facial_features(image)
            
            if face_data:
                return render_template('index.html', measurements=face_data)
    
    return render_template('index.html', measurements=None)

if __name__ == '__main__':
    app.run(debug=True)
