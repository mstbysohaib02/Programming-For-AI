from flask import Flask, render_template
import requests

app = Flask(__name__)

Weather_api = "c5696a142d1040d698f210409251603"
weather_url = "https://api.weatherapi.com/v1/current.json"  

@app.route('/', methods=['GET', 'POST'])
def index():
    params = {
        "key": Weather_api,
        "q": "London"  
    }
    
    try:
        response = requests.get(weather_url, params=params)
        response.raise_for_status()  # Raise an error for bad responses (4xx, 5xx)
        weather_data = response.json()
    except requests.exceptions.RequestException as e:
        weather_data = {"error": str(e)}  # Handle API errors

    return render_template("index.html", weather=weather_data)

if __name__ == "__main__":
    app.run(debug=True)

# def index():
#     par = {"weather_key": Weather_api,
#            "q": "London"}
#     response = requests.get(weather_url, params=par)
#     weather_data = response.json()

#     return render_template("index.html", weather = weather_data)


# if __name__ == "__main__":
#     app.run(debug=True)
